var b,bi
var ghost, gi
var doorgroup
var door
function preload(){
  bi=loadImage("tower.png") 
  gi=loadImage("ghost-jumping.png")
  door=loadImage("door.png") 
}

function setup(){
 createCanvas (500,600) 
 b=createSprite(250,300,500,600)
 b.addImage("b",bi)
  b.velocityY=2
  
  ghost=createSprite(250,200,20,20)
  ghost.addImage("g", gi)
  ghost.scale=0.4
  ghost.velocityY=5
  
  doorgroup=new Group()
}
function draw(){
 background("green") 
                
   if(b.y>600){
    b.y=300
  }
  
  if(keyDown("space")){
    ghost.velocityY=-5
  }
   doors();   
  ghost.velocityY=ghost.velocityY+0.5
  
 drawSprites() ;
}


function doors(){
  if (frameCount%60===0){
     door=createSprite(random(10,490),20,20,20)
     door.addImage("door.png", door)
    door.velocityY=3
//door.addGroup(doorgroup)    
 }
}



